from django.contrib import admin
from .models import PerevalAdded
# Register your models here.
admin.site.register(PerevalAdded)